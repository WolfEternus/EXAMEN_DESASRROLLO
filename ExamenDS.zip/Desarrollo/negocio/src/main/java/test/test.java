/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import mx.desarrollo.entidad.Usuarios;
import mx.desarrollo.integracion.ServiceFacadeLocator;

/**
 *
 * @author lukki
 */
public class test {
    public static void main(String[] args) {
        Usuarios usuario = new Usuarios();
        
        usuario = ServiceFacadeLocator.getInstanceFacadeUsuario().login("contra123","francisco.reyes.parra@uabc.edu.mx");
        
        if(usuario.getUser() != null){
            System.out.println("Login exitoso con el correo: " + usuario.getUser());
        }else{
            System.out.println("No se encontro registro");
        }
    }
}
