/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.desarrollo.entidad;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "profesores")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Profesores.findAll", query = "SELECT p FROM Profesores p")
    , @NamedQuery(name = "Profesores.findByIdProfesores", query = "SELECT p FROM Profesores p WHERE p.idProfesores = :idProfesores")
    , @NamedQuery(name = "Profesores.findByNombre", query = "SELECT p FROM Profesores p WHERE p.nombre = :nombre")
    , @NamedQuery(name = "Profesores.findByApellido", query = "SELECT p FROM Profesores p WHERE p.apellido = :apellido")
    , @NamedQuery(name = "Profesores.findByRfc", query = "SELECT p FROM Profesores p WHERE p.rfc = :rfc")})
public class Profesores implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idProfesores")
    private Integer idProfesores;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "apellido")
    private String apellido;
    @Column(name = "RFC")
    private String rfc;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "profesores")
    private Asignacionunidad asignacionunidad;

    public Profesores() {
    }

    public Profesores(Integer idProfesores) {
        this.idProfesores = idProfesores;
    }

    public Integer getIdProfesores() {
        return idProfesores;
    }

    public void setIdProfesores(Integer idProfesores) {
        this.idProfesores = idProfesores;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public Asignacionunidad getAsignacionunidad() {
        return asignacionunidad;
    }

    public void setAsignacionunidad(Asignacionunidad asignacionunidad) {
        this.asignacionunidad = asignacionunidad;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idProfesores != null ? idProfesores.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Profesores)) {
            return false;
        }
        Profesores other = (Profesores) object;
        if ((this.idProfesores == null && other.idProfesores != null) || (this.idProfesores != null && !this.idProfesores.equals(other.idProfesores))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.desarrollo.entidad.Profesores[ idProfesores=" + idProfesores + " ]";
    }
    
}
