/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.desarrollo.entidad;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "asignacionunidad")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Asignacionunidad.findAll", query = "SELECT a FROM Asignacionunidad a")
    , @NamedQuery(name = "Asignacionunidad.findByIdasignacionunidad", query = "SELECT a FROM Asignacionunidad a WHERE a.idasignacionunidad = :idasignacionunidad")
    , @NamedQuery(name = "Asignacionunidad.findByIdprofesor", query = "SELECT a FROM Asignacionunidad a WHERE a.idprofesor = :idprofesor")})
public class Asignacionunidad implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "idasignacionunidad")
    private int idasignacionunidad;
    @Id
    @Basic(optional = false)
    @Column(name = "idprofesor")
    private Integer idprofesor;
    @JoinColumn(name = "idprofesor", referencedColumnName = "idProfesores", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Profesores profesores;
    @JoinColumn(name = "idunidadaca", referencedColumnName = "idUnidadA")
    @ManyToOne
    private Unidadacademica idunidadaca;

    public Asignacionunidad() {
    }

    public Asignacionunidad(Integer idprofesor) {
        this.idprofesor = idprofesor;
    }

    public Asignacionunidad(Integer idprofesor, int idasignacionunidad) {
        this.idprofesor = idprofesor;
        this.idasignacionunidad = idasignacionunidad;
    }

    public int getIdasignacionunidad() {
        return idasignacionunidad;
    }

    public void setIdasignacionunidad(int idasignacionunidad) {
        this.idasignacionunidad = idasignacionunidad;
    }

    public Integer getIdprofesor() {
        return idprofesor;
    }

    public void setIdprofesor(Integer idprofesor) {
        this.idprofesor = idprofesor;
    }

    public Profesores getProfesores() {
        return profesores;
    }

    public void setProfesores(Profesores profesores) {
        this.profesores = profesores;
    }

    public Unidadacademica getIdunidadaca() {
        return idunidadaca;
    }

    public void setIdunidadaca(Unidadacademica idunidadaca) {
        this.idunidadaca = idunidadaca;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idprofesor != null ? idprofesor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Asignacionunidad)) {
            return false;
        }
        Asignacionunidad other = (Asignacionunidad) object;
        if ((this.idprofesor == null && other.idprofesor != null) || (this.idprofesor != null && !this.idprofesor.equals(other.idprofesor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.desarrollo.entidad.Asignacionunidad[ idprofesor=" + idprofesor + " ]";
    }
    
}
